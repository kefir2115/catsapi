(function() {
    var app, fs, uid;

    var users = {};
    var dfile = "users.json";

    exports.load = (ap, f, id) => {
        app = ap;
        fs = f;
        uid = id;
        /*
            query params:
                login - email/nickname
                password - then hash using hash(str) function
        */
        app.get('/auth', (req, res) => {
            const q = req.query;
            let login = q.login;
            let pass = q.password;
            if(login!=null && pass!=null) {
                let found = false;
                let hashed = hash(pass);
                let session = hash(hashed+new Date().getTime())+new Date().getTime();
                Object.keys(users.users).forEach((e, i) => {
                    let v = users.users[e];
                    if(v.login == login && v.password == hashed && !found) {
                        users.tokens[i] = session;
                        found = true;
                    }
                });
                res.status(200).send(""+(found?session:-1));
            } else res.status(200).send("-1");
        });
         /*
            query params:
                name - user name
                login - email/nickname
                password - then hash using hash(str) function
        */
        app.get('/register', (req, res) => {
            const q = req.query;
            let name = q.name;
            let login = q.login;
            let pass = q.password;
            if(name!=null && login!=null && pass!=null) {
                let hashed = hash(pass);
                let id = uid.v4();
                let tag = Math.floor(Math.random()*9999);
                let xp = 0;
                let skin = 0;
                let i = Object.keys(users.users).length;

                users.users[i] = {};
                let o = users.users[i];
                o.uuid = id;
                o.name = name;
                o.login = login;
                o.password = hashed;
                o.tag = tag;
                o.xp = xp;
                o.skin = skin;

                res.status(200).send(JSON.stringify(users.users[i]));
            } else res.status(200).send("{}");
        });
        /*
           query params:
               login - email/nickname
               password - then hash using hash(str) function
       */
        app.get('/login', (req, res) => {
            const q = req.query;
            let login = q.login;
            let pass = q.password;
            if(login!=null && pass!=null) {
                let found = false;
                let hashed = hash(pass);
                let session = hash(hashed+new Date().getTime())+new Date().getTime();
                Object.keys(users.users).forEach((e, i) => {
                    let v = users.users[e];
                    if(v.login == login && v.password == hashed && !found) {
                        users.tokens[i] = session;
                        found = true;
                    }
                });
                res.status(200).send(""+(found?session:-1));
            } else res.status(200).send("-1");
        });

         /*
            query params:
                session
        */
        app.get('/getInfoBySession', (req, res) => {
            const q = req.query;
            let session = q.session;
            if(session!=null) {
                let found = false;
                let findex = -1;
                Object.keys(users.tokens).forEach((e, i) => {
                    let v = users.tokens[e];
                    if(v==session) {
                        found = true;
                        findex = i;
                    }
                });
                res.status(200).send(found?JSON.stringify(users.users[findex]):"{}");
            } else res.status(200).send("{}");
        });
        
         /*
            query params:
                login - email/nickname
                password - then hash using hash(str) function
        */
        app.get('/removeUser', (req, res) => {
            const q = req.query;
            let login = q.login;
            let pass = q.password;
            if(login!=null && pass!=null) {
                let found = false;
                let findex = -1;
                Object.keys(users.users).forEach((e, i) => {
                    let v = users.users[e];
                    if(login==v.login && pass==v.password) {
                        found = true;
                        findex = i;
                    }
                });
                if(found) removeUser(findex);
                res.status(200).send("{}");
            } else res.status(200).send("{}");
        });
    }

    exports.fileOperations = () => {
        fs.writeFile(dfile, "", { flag: 'wx' }, function (err) {});
        if(fs.existsSync(dfile)) fs.readFile(dfile, function(err, data) {
            if(data.length!=0) users = JSON.parse(fs.readFileSync(dfile, "utf8"));
            else users = JSON.parse('{"users":{},"tokens":{}}');
        });
    };
    exports.save = () => {
        fs.writeFileSync(dfile, JSON.stringify(users));
    }

    const hash = (str, seed = 0) => {
        let h1 = 0xdeadbeef ^ seed, h2 = 0x41c6ce57 ^ seed;
        for(let i = 0, ch; i < str.length; i++) {
            ch = str.charCodeAt(i);
            h1 = Math.imul(h1 ^ ch, 2654435761);
            h2 = Math.imul(h2 ^ ch, 1597334677);
        }
        h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
        h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
        
        return 4294967296 * (2097151 & h2) + (h1 >>> 0);
    };
    const removeUser = (index) => {
        delete users.users[Object.keys(users.users)[index]];
        delete users.tokens[index];
    }
})();