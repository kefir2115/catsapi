const app = require("express")();
const fs = require('fs');
var allData = {};

const port = 6969;
const dfile = "data.json";

app.listen(
    port,
    () => {
        fs.writeFile(dfile, "", { flag: 'wx' }, function (err) {});
        if(fs.existsSync(dfile)) fs.readFile(dfile, function(err, data) {
            if(data.length!=0) allData = JSON.parse(fs.readFileSync(dfile, "utf8"));
            else allData = JSON.parse('{"lobbys":{},"lobbyAmt":0}');
        });
        console.log(allData);
        console.log('Port: http://127.0.0.1:'+port);
    }
);
app.get('/', (req, res) => {
    try {
        var data = fs.readFileSync('map.html', 'utf8');
        res.status(200).send(data);
    } catch (err) {
        console.error(err);
    }
});
app.get('/lobby/:id', (req, res) => {
    const {id} = req.params;
    res.status(200).send(allData.lobbys[id]);
});
app.get('/createLobby', (req, res) => {
    let q = req.query;
    allData.lobbys[allData.lobbyAmt] = {};
    let o = allData.lobbys[allData.lobbyAmt];
    o.id = allData.lobbyAmt;
    o.players = [];
    o.lobbySettings = [];
    allData.lobbyAmt++;
    res.status(200).send(allData.lobbys[allData.lobbyAmt-1]);
});
app.get('/lobby/:id/players', (req, res) => {
    const {id} = req.params;
    try {
        res.status(200).send(allData.lobbys[id].players);
    } catch (err) {
        res.status(418).send("[]");
    }
});
app.get('/lobby/:id/settings', (req, res) => {
    const {id} = req.params;
    try {
        res.status(200).send(allData.lobbys[id].lobbySettings);
    } catch (err) {
        res.status(418).send("[]");
    }
});
app.get('/lobby/:id/addPlayer', (req, res) => {
    const {id} = req.params;
    let q = req.query;
    if(q.uuid!=null) {
        try {
            if(!allData.lobbys[id].players.includes(q.uuid)) allData.lobbys[id].players.push(q.uuid);
            res.status(200).send(allData.lobbys[id].players);
        } catch (err) {
            res.status(418).send("[]");
        }
    } else {
        res.status(200).send("[]");
    }
});
app.get('/lobby/:id/removePlayer', (req, res) => {
    const {id} = req.params;
    let q = req.query;
    if(q.uuid!=null) {
        try {
            allData.lobbys[id].players.splice(q.uuid, allData.lobbys[id].players.indexOf(q.uuid));
            res.status(200).send(allData.lobbys[id].players);
        } catch (err) {
            res.status(200).send("[]");
        }
    } else {
        res.status(200).send("[]");
    }
});