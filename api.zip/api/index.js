const auth = require('./auth');
const app = require("express")();
const fs = require('fs');
const uuid = require('uuid');
var allData = {};

const port = 6969;
const dfile = "data.json";
auth.load(app, fs, uuid);

setInterval(() => {
    fs.writeFileSync(dfile, JSON.stringify(allData));
    auth.save();
}, 5000);

app.listen(
    port,
    () => {
        auth.fileOperations();
        fs.writeFile(dfile, "", { flag: 'wx' }, function (err) {});
        if(fs.existsSync(dfile)) fs.readFile(dfile, function(err, data) {
            if(data.length!=0) allData = JSON.parse(fs.readFileSync(dfile, "utf8"));
            else allData = JSON.parse('{"lobbys":{}}');
            removeLobbyLoop();
        });
        console.log(allData);
        console.log('Port: http://127.0.0.1:'+port);
    }
);
app.get('/', (req, res) => {
    try {
        var data = fs.readFileSync('map.html', 'utf8');
        res.status(200).send(data);
    } catch (err) {
        console.error(err);
    }
});
app.get('/lobbys', function(req, res) {
    let d = Object.keys(allData.lobbys);
    res.status(200).send(d);
});
app.get('/lobby/:id', (req, res) => {
    const {id} = req.params;
    res.status(200).send(allData.lobbys[id]);
});
app.get('/createLobby', (req, res) => {
    let q = req.query;
    let obj = Object.keys(allData.lobbys);
    let i = obj.length==0?0:allData.lobbys[obj[obj.length-1]].id+1;
    allData.lobbys[i] = {};
    let o = allData.lobbys[i];
    o.id = i;
    o.players = [];
    o.lobbySettings = [];
    res.status(200).send(allData.lobbys[i]);
});
app.get('/lobby/:id/players', (req, res) => {
    const {id} = req.params;
    try {
        res.status(200).send(allData.lobbys[id].players);
    } catch (err) {
        res.status(418).send("[]");
    }
});
app.get('/lobby/:id/settings', (req, res) => {
    const {id} = req.params;
    try {
        res.status(200).send(allData.lobbys[id].lobbySettings);
    } catch (err) {
        res.status(418).send("[]");
    }
});
app.get('/lobby/:id/addPlayer', (req, res) => {
    const {id} = req.params;
    let q = req.query;
    if(q.uuid!=null) {
        try {
            if(!allData.lobbys[id].players.includes(q.uuid)) allData.lobbys[id].players.push(q.uuid);
            res.status(200).send(allData.lobbys[id].players);
        } catch (err) {
            res.status(418).send("[]");
        }
    } else {
        res.status(200).send("[]");
    }
});
app.get('/lobby/:id/removePlayer', (req, res) => {
    const {id} = req.params;
    let q = req.query;
    if(q.uuid!=null) {
        try {
            console.log(allData.lobbys[id].players);
            delete allData.lobbys[id].players[allData.lobbys[id].players.indexOf(q.uuid)];
            console.log(allData.lobbys[id].players);
            allData.lobbys[id].players = allData.lobbys[id].players.filter((e) => { return e!=null; });
            res.status(200).send(allData.lobbys[id].players);
            if(allData.lobbys[id].players.length==0) removeLobby(id);
        } catch (err) {
            res.status(200).send("[]");
        }
    } else {
        res.status(200).send("[]");
    }
});
app.get('/deleteLobby/:id', function (req, res) {
    const {id} = req.params;
    res.status(200).send(removeLobby(id)+"");
});

async function removeLobbyLoop() {
    Object.keys(allData.lobbys).forEach((e, i) => {
        let v = allData.lobbys[e];
        if(v.players.length==0) removeLobby(v.id);
    });
    setTimeout(() => {
        removeLobbyLoop();
    }, 60000);
}

function removeLobby(id) {
    delete allData.lobbys[id];
    return allData.lobbys[id]==null;
}